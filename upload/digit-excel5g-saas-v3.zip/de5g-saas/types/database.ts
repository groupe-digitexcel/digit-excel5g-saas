export type Json = string | number | boolean | null | { [key: string]: Json } | Json[]

export interface Database {
  public: {
    Tables: {
      profiles: {
        Row: {
          id: string
          name: string
          email: string
          phone: string | null
          role: 'user' | 'admin'
          plan: 'Free' | 'Starter' | 'Pro' | 'VIP'
          credits: number
          status: 'active' | 'suspended'
          created_at: string
          updated_at: string
        }
        Insert: Omit<Database['public']['Tables']['profiles']['Row'], 'created_at' | 'updated_at'>
        Update: Partial<Database['public']['Tables']['profiles']['Insert']>
      }
      ai_jobs: {
        Row: {
          id: string
          user_id: string
          job_type: 'image' | 'photo' | 'flyer' | 'song'
          prompt: string | null
          output_url: string | null
          output_data: Json | null
          status: 'pending' | 'completed' | 'failed'
          credits_used: number
          provider: string | null
          created_at: string
        }
        Insert: Omit<Database['public']['Tables']['ai_jobs']['Row'], 'id' | 'created_at'>
        Update: Partial<Database['public']['Tables']['ai_jobs']['Insert']>
      }
      payments: {
        Row: {
          id: string
          user_id: string
          method: 'MTN MoMo' | 'Orange Money'
          amount: number
          reference: string
          payer_phone: string | null
          status: 'pending' | 'approved' | 'rejected'
          credits_awarded: number
          verified_by: string | null
          created_at: string
          updated_at: string
        }
        Insert: Omit<Database['public']['Tables']['payments']['Row'], 'id' | 'created_at' | 'updated_at'>
        Update: Partial<Database['public']['Tables']['payments']['Insert']>
      }
    }
    Views: Record<string, never>
    Functions: Record<string, never>
    Enums: Record<string, never>
  }
}

export type Profile = Database['public']['Tables']['profiles']['Row']
export type AIJob   = Database['public']['Tables']['ai_jobs']['Row']
export type Payment = Database['public']['Tables']['payments']['Row']
